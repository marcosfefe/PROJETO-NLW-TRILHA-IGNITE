import axios from 'axios'

export const api = axios.create({
  baseURL: 'http://192.1.0.183:3333',
})
